# ProStavki Telegram Bot

Telegram-бот для ставок: стратегии, бонусы и автоматическая проверка депозита.

## Запуск на Railway

1. Создайте проект на [railway.app](https://railway.app)
2. Подключите репозиторий GitHub с этим кодом
3. Установите переменные:
   - `API_TOKEN`: токен от BotFather
   - `ADMIN_CHAT_ID`: ID вашего чата/пользователя
4. Команда запуска:
   ```bash
   python main.py
   ```